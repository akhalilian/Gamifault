import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Stack;
import java.util.StringTokenizer;

import static java.lang.Math.abs;
import static java.lang.Math.max;
import static java.lang.Math.min;

public class Main {
	
	static final int MOD = (int) 1e9 + 7;
	
	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		PrintWriter out = new PrintWriter(System.out);
		
		int n, t;
		
		n = sc.nextInt();
		t = sc.nextInt();
		
		if(t > 1)
		{
			int to = Math.min(100, t);
			int m = (n * to);
			
			int arr[] = new int[m];
			
			for(int i = 0; i < n; ++i) arr[i] = sc.nextInt();
			for(int i = n; i < m; ++i) arr[i] = arr[i - n];
			
			int dp[] = new int[m];
			
			int max = 1;
			
			Arrays.fill(dp, 1);
			
			for(int i = 1; i < m; ++i)
				for(int j = i - 1; j >= 0; --j)
					if(arr[j] <= arr[i] && dp[j] + 1 > dp[i])
						max = Math.max(max, dp[i] = dp[j] + 1);
			
			int max2 = 1;
			for(int i = m - 2 * n; i < m - n; ++i) max2 = Math.max(max2, dp[i]);
			
			out.println(max + (t - to) * (max - max2));
		}
		else
		{
			int arr[] = new int[n];
			int max = 1;
			
			for(int i = 0; i < n; ++i) arr[i] = sc.nextInt();
			int dp[] = new int[n];
			
			for(int i = 1; i < n; ++i)
				for(int j = i - 1; j >= 0; --j)
					if(arr[j] <= arr[i] && dp[j] + 1 > dp[i])
						max = Math.max(max, dp[i] = dp[j] + 1);
			
			out.println(max);
		}
		
		
		
		out.flush();
		out.close();
	}
	
	static class Pair implements Comparable<Pair> {
		int a, b;
		
		public Pair(int x, int y) {
			a = x; b = y;
		}
		
		@Override
		public int compareTo(Pair p) {
			return (a == p.a)?b - p.b:a - p.a; 
		}
		
		@Override
		public String toString() {
			return a + " " + b;
		}
	}
	
	static class Scanner{
		StringTokenizer st;
		BufferedReader br;

		public Scanner(InputStream s){	br = new BufferedReader(new InputStreamReader(s));}

		public Scanner(FileReader r){	br = new BufferedReader(r);}

		public String next() throws IOException 
		{
			while (st == null || !st.hasMoreTokens()) 
				st = new StringTokenizer(br.readLine());
			return st.nextToken();
		}

		public int nextInt() throws IOException {return Integer.parseInt(next());}

		public long nextLong() throws IOException {return Long.parseLong(next());}

		public String nextLine() throws IOException {return br.readLine();}

		public double nextDouble() throws IOException { return Double.parseDouble(next()); }

		public boolean ready() throws IOException {return br.ready();}
	}
}