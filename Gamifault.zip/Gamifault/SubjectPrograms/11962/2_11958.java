// ~/BAU/ACM-ICPC/Teams/A++/BlackBurn95

import java.io.*;
import java.util.*;
import java.math.*;
import static java.lang.Math.*;
import static java.lang.Integer.parseInt;
import static java.lang.Long.parseLong;
import static java.lang.Double.parseDouble;
import static java.lang.String.*;

public class Main {

    static int N;
    static int [] BIT,seg;
    
    public static void main(String[] args) throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
                                              //(new FileReader("input.in"));
        StringBuilder out = new StringBuilder();
        StringTokenizer tk;
      
        tk = new StringTokenizer(in.readLine());
        int n = parseInt(tk.nextToken()),t = parseInt(tk.nextToken());
        int [] a = new int[n];
        int [] f = new int[301];
        
        tk = new StringTokenizer(in.readLine());
        
        for(int i=0; i<n; i++) {
            a[i] = parseInt(tk.nextToken());
            f[a[i]]++;
        }
        
        N = 300;
        BIT = new int[N+1];
        int [] dp1 = new int[N+1];
        int j;
        for(int i=0; i<n*n; i++) {
            j = i%n;
            dp1[a[j]] = max(dp1[a[j]],get(a[j])+1);
            update(a[j],dp1[a[j]]);
        }
        
        seg = new int[4*N+1];
        
        int [] dp2 = new int[N+1];
        
        for(int k=1; k<=n; k++) {
            for(int i=n-1; i>=0; i--) {
                dp2[a[i]] = max(dp2[a[i]], get(1,0,300,a[i],300)+1);
                update(1,0,300,a[i],dp2[a[i]]);
            }
        }
        /*
        for(int i=0; i<n; i++)
            System.out.print(dp1[i]+" ");
        System.out.println("\n****");
        for(int i=0; i<n; i++)
            System.out.print(dp2[i]+" ");
        System.out.println("\n*****");
        */
        long ans = 0;
        for(int i=0; i<n; i++) {
            for(j=0; j<n; j++) {
                if(a[j]>=a[i]) {
                    ans = max(ans, (long)dp1[i]+(long)dp2[j]+(long)(t-2*n)*(long)max(f[a[i]],f[a[j]]));
                    //System.out.println(i+" , "+j+" , "+f[a[i]]+" "+f[a[j]]+" "+ans);
                }
            }
        }
        
        System.out.println(ans);
    }
    
    static void update(int p,int s,int e,int i,int v) {
        if(s==e) {
            seg[p] = v;
            return;
        }
        
        if(i<=(s+e)/2)
            update(2*p,s,(s+e)/2,i,v);
        else update(2*p+1,(s+e)/2+1,e,i,v);
        
        seg[p] = max(seg[2*p],seg[2*p+1]);
    }
    
    static int get(int p,int s,int e,int a,int b) {
        if(s>=a && e<=b)
            return seg[p];
        if(s>b || e<a)
            return -(int)1e9;
        
        return max(get(2*p,s,(s+e)/2,a,b), get(2*p+1,(s+e)/2+1,e,a,b));
    }
    
    static void update(int i,int v) {
        while(i<=N) {
            BIT[i] = max(BIT[i],v);
            i += (i & -i);
        }
    }
    
    static int get(int i) {
        int ans = -1;
        while(i>0) {
            ans = max(ans, BIT[i]);
            i -= (i & -i);
        }
        return ans;
    }
}