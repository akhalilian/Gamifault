import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.TreeMap;

public class X {

	public static void main(String args[]) throws IOException {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();

		TreeMap<Integer, Integer> tm = new TreeMap<Integer, Integer>();

		for (int i = 0; i < n * n; i++) {
			int x = s.nextInt();

			if (tm.containsKey(x))
				tm.put(x, tm.get(x) + 1);
			else
				tm.put(x, 1);
		}

		TreeMap<Integer, Integer> tm2 = new TreeMap<Integer, Integer>();

		if (n == 1) {
			System.out.println(tm.firstKey());
			return;
		}

		while (!tm.isEmpty()) {

			int x = tm.lastKey();
			// System.out.println("in" + x);
			int val = tm.get(x);
			if (val == 1)
				tm.remove(x);
			else
				tm.replace(x, val - 1);

			for (Entry<Integer, Integer> q : tm2.entrySet()) {

				int pl = gcd(Math.max(q.getKey(), x), Math.min(q.getKey(), x));
				if (tm.containsKey(pl)) {
					int tv = tm.get(pl);
					tv -= Math.pow(2, q.getValue());
					if (tv <= 0)
						tm.remove(pl);
					else
						tm.replace(pl, tv);

					// System.out.println("in 23 " + pl + " " + tv);
				}
			}

			if (!tm2.containsKey(x))
				tm2.put(x, 1);
			else
				tm2.replace(x, tm2.get(x) + 1);

		}

		for (Entry<Integer, Integer> x : tm2.entrySet()) {
			for (int i = 0; i < x.getValue(); i++)
				System.out.print(x.getKey() + " ");
		}
		System.out.flush();
	}

	public static int gcd(int a, int b) {
		if (b == 0)
			return a;

		return gcd(b, a % b);
	}
}