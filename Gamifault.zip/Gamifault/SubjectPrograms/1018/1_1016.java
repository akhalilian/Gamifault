import java.util.Scanner;
public class test{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt(),b=sc.nextInt();
        System.out.print(Math.min(a,b));
        a=Math.max(a,b);
        b=Math.min(a,b);
        a-=b;
        if(a<2)System.out.println(" "+0);
        else System.out.println(" "+a/2);
    }
}