import java.util.Scanner;

/**
 * Created by sanjayarvind on 12/02/2017 AD.
 */
public class CR322 {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt(), b = sc.nextInt();
        System.out.print(Math.min(a, b));
        if (a < b) {
            int t = a;
            a = b;
            b = t;
        }
        a -= b;
        if (a < 2) System.out.println(" " + 0);
        else System.out.println(" " + a / 2);
    }
}