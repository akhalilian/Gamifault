import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub

		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		int n = Integer.parseInt(in.readLine());
		int[] store = new int[n];
		boolean flag = false;
		boolean flag2 = false;
		int count = 0;
		boolean[] visited = new boolean[n];
		int turn = 0;
		String[] in1 = in.readLine().split(" ");
		for(int i = 0; i < n; i++){
			store[i] = Integer.parseInt(in1[i]);
		}
		int mode = 0;
		while(!flag){
			flag = true;
			if(mode == 0){
				for(int i = 0; i < store.length; i++){
					if(count >= store[i] && !visited[i]){
						count++;
						visited[i] = true;
						flag = false;
					}
				}
				mode = 1;
			}
			else{
				for(int i = store.length - 1; i >= 0 ; i--){
					if(count >= store[i] && !visited[i]){
						count++;
						visited[i] = true;
						flag = false;
					}
				}
				mode = 0;
			}
			turn++;
		}
		turn -=2;
		System.out.print(turn);
	}

}