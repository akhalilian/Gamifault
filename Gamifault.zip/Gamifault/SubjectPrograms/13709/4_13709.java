import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Codeforces583A {
	public static void main(String args[])
	{
		Scanner s = new Scanner(System.in);
		Set<Integer> hor = new HashSet<Integer>();
		Set<Integer> ver = new HashSet<Integer>();
		ArrayList<Integer> result = new ArrayList<Integer>();
		int n = s.nextInt();
		int i=0;
		int day = 1;
		while(i<n*n)
		{
			int a = s.nextInt();
			int b = s.nextInt();
			if(!(hor.contains(a) || ver.contains(b)))
			{
				result.add(day);
				hor.add(a);
				ver.add(b);
			}
			day++;
			i++;
		}
		s.close();
		for (int j = 0; j < result.size(); j++) {
			System.out.println(result.get(j));
		}
		
		
	}
}