import java.util.Scanner;

public class Codeforces583A {
	public static void main(String args[])
	{
		Scanner s = new Scanner(System.in);
		String test = "";
		int n = s.nextInt();
		int i=0;
		int day = 1;
		int result[] = new int[n*n];
		while(i<n*n)
		{
			int a = s.nextInt();
			int b = s.nextInt();
			if(!(test.contains(Integer.toString(a)) || test.contains(Integer.toString(b))))
			{
				result[i] = day;
				test+=Integer.toString(a);
				test+=Integer.toString(b);
			}
			day++;
			i++;
		}
		s.close();
		for (int j = 0; j < result.length; j++) {
			if(result[j]!=0)
				System.out.print(result[j]+" ");
		}
		
		
	}
}