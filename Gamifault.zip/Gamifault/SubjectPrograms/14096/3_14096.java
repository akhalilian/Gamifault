//package Codeforces.Div2A_323.Code1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

/*
 * some cheeky quote
 */

public class Main
{
    FastScanner in;
    PrintWriter out;

    public void solve() throws IOException
    {
        int size = in.nextInt();
        boolean h[] = new boolean[size];
        boolean v[] = new boolean[size];

        int limit = size * size;
        String result = "";
        for (int i = 1; i <= limit; i++)
        {
            int row = in.nextInt() - 1;
            int col = in.nextInt() - 1;
            if (!h[row] && !v[col])
            {
                result += i + " ";
                h[row] = true;
                v[col] = true;
            }
        }
        System.out.println(result);
    }

    public void run()
    {
        try
        {
            in = new FastScanner();
            out = new PrintWriter(System.out);

            solve();

            out.close();
        } catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    class FastScanner
    {
        BufferedReader br;
        StringTokenizer st;

        FastScanner()
        {
            br = new BufferedReader(new InputStreamReader(System.in));
        }

        String next()
        {
            while (st == null || !st.hasMoreTokens())
            {
                try
                {
                    st = new StringTokenizer(br.readLine());
                } catch (IOException e)
                {
                    e.printStackTrace();
                }
            }
            return st.nextToken();
        }

        int nextInt()
        {
            return Integer.parseInt(next());
        }
    }

    public static void main(String[] arg)
    {
        new Main().run();
    }
}