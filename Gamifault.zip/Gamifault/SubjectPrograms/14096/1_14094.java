//package Codeforces.Div2A_323.Code1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

/*
 * some cheeky quote
 */

public class Main
{
    FastScanner in;
    PrintWriter out;

    public void solve() throws IOException
    {
        int size = in.nextInt();
        int a[][] = new int[size][size];
        int limit = size * size;
        int lastDay = 0;
        for (int i = 0; i < limit; i++)
        {
            int row = in.nextInt() - 1;
            int col = in.nextInt() - 1;
            boolean isNone = false;
            if (row - 1 >= 0 && a[row - 1][col] != 0)
            {
                isNone = true;
            }
            if (row + 1 < a.length && a[row + 1][col] != 0)
            {
                isNone = true;
            }
            if (col - 1 >= 0 && a[row][col - 1] != 0)
            {
                isNone = true;
            }
            if (col + 1 < a.length && a[row][col + 1] != 0)
            {
                isNone = true;
            }
            if (!isNone)
            {
                a[row][col] = 2;
                lastDay = i + 1;
            }
        }
        if (lastDay == 1)
        {
            System.out.println(1);
        } else
        {
            System.out.println(1 + " " + lastDay);
        }

    }

    public void run()
    {
        try
        {
            in = new FastScanner();
            out = new PrintWriter(System.out);

            solve();

            out.close();
        } catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    class FastScanner
    {
        BufferedReader br;
        StringTokenizer st;

        FastScanner()
        {
            br = new BufferedReader(new InputStreamReader(System.in));
        }

        String next()
        {
            while (st == null || !st.hasMoreTokens())
            {
                try
                {
                    st = new StringTokenizer(br.readLine());
                } catch (IOException e)
                {
                    e.printStackTrace();
                }
            }
            return st.nextToken();
        }

        int nextInt()
        {
            return Integer.parseInt(next());
        }
    }

    public static void main(String[] arg)
    {
        new Main().run();
    }
}