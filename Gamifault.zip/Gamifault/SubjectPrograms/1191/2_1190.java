import java.util.Scanner;

public class JavaApplication31 {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int[] t = new int[n];
        int[] a = new int[n];

        for (int i = 0; i < n; i++) {
            t[i] = scan.nextInt();
        }
        int max = t[n - 1];
        a[n - 1] = 0;
        for (int i = n - 2; i >= 0; i--) {

            if (t[i] >= max) {
                max = t[i];
                t[i] = 0;
            } else {
                a[i] = max - t[i] + 1;
            }
        }
        for (int i = 0; i < n; i++) {
            System.out.print(a[i] + " ");
        }

    }

}