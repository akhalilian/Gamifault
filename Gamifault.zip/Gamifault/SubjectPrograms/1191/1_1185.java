import java.util.Scanner;

public class JavaApplication31 {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int[] t = new int[n];
        int[] a = new int[n];
        int imax = 0;
        for (int i = 0; i < n; i++) {
            t[i] = scan.nextInt();
            if (t[i] > t[imax]) {
                imax = i;
            }
        }
        int p = 0;
        while (imax <= n - 1) {
            remplir(a, t, p, imax);
            p = imax;
            imax = maximum(t, imax + 1);

        }

        int j;
        for (j = 0; j < n; j++) {
            System.out.print(a[j] + " ");
        }

    }

    public static void remplir(int a[], int t[], int posInit, int posFinal) {
        for (int i = posInit; i < posFinal; i++) {
            a[i] = t[posFinal] - t[i] + 1;
        }
    }

    public static int maximum(int t[], int posInit) {
        int imax = posInit;
        for (int i = posInit + 1; i < t.length; i++) {
            if (t[imax] < t[i]) {
                imax = i;
            }
        }
        return imax;
    }
}