import java.util.*;
import java.io.PrintWriter;

public class A583 implements Runnable {
	private Scanner in = new Scanner(System.in);
	private PrintWriter out = new PrintWriter(System.out);
	private int n;
	private int r[][];
	private int s[][];
	private String ans = "";

	HashMap<Integer, String> newA = new HashMap<Integer, String>();
	HashMap<Integer, String> newB = new HashMap<Integer, String>();


	
	public static void main(String[] args) {
		new Thread(new A583()).start();
	}

	private void read() {
		n = in.nextInt();
		int temp = 0;

		r = new int[n*n][2];

		s = new int[n][n];

		for(int i = 0; i < n*n; i++ ) {
			for(int j = 0; j < 2; j++) {
				r[i][j] = in.nextInt();
			}

			if(newA.containsKey(r[i][0]) || newB.containsKey(r[i][1])){
				
			} else {
				temp = i;
				ans += temp + 1 + " ";
				newA.put(r[i][0], "");
				newB.put(r[i][1], "");
			}
		}
	}

	private void solve() {
		
		
		
	}

	private void write() {
		
		out.println(ans.trim());
		
	}


	public void run() {
		read();
		solve();
		write();
		out.close();
	} 
}