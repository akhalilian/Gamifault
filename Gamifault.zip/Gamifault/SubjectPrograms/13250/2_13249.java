import java.util.*;
import java.io.PrintWriter;

public class A583 implements Runnable {
	private Scanner in = new Scanner(System.in);
	private PrintWriter out = new PrintWriter(System.out);
	private int n;
	private int r[][];
	private int s[][];
	private String ans = "";

	HashMap<Integer, String> newmap = new HashMap<Integer, String>();

	
	public static void main(String[] args) {
		new Thread(new A583()).start();
	}

	private void read() {
		n = in.nextInt();
		int temp = 0;

		r = new int[n*n][2];

		s = new int[n][n];

		for(int i = 0; i < n*n; i++ ) {
			for(int j = 0; j < 2; j++) {
				r[i][j] = in.nextInt();
			}

			if(newmap.containsKey(r[i][0]) || newmap.containsKey(r[i][1])){
				
			} else {
				temp = i;
				ans += temp + 1 + " ";
				newmap.put(r[i][0], "");
				newmap.put(r[i][1], "");
			}
		}
	}

	private void solve() {
		
		
		
	}

	private void write() {
		
		out.println(ans.trim());
		
	}


	public void run() {
		read();
		solve();
		write();
		out.close();
	} 
}